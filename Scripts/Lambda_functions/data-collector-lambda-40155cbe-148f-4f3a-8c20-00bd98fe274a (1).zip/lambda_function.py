import boto3
import requests  # Assuming this was omitted in your summary but used for API calls

# Initialize boto3 client
s3 = boto3.client('s3')

def lambda_handler(event, context):
    api_endpoints = [
        ('https://data.cityofnewyork.us/resource/h9gi-nx95.csv?$order=crash_date DESC', 'crashes.csv'),
        ('https://data.cityofnewyork.us/resource/f55k-p6yu.csv?$order=crash_date DESC', 'person.csv'),
        ('https://data.cityofnewyork.us/resource/bm4k-52h4.csv?$order=crash_date DESC', 'vehicles.csv')
    ]

    # Updated bucket name for reading historical data
    historical_bucket_name = 'historical-data-bucket-ia-final'
    historical_prefix = 'new_data/'

    # Updated bucket name for writing new daily data
    daily_data_bucket_name = 'daily-data-bucket-ia-final'
    daily_data_prefix = 'daily_data/'

    for api_endpoint, filename in api_endpoints:
        response = requests.get(api_endpoint)
        if response.status_code == 200:
            # Writing to the new daily data location
            s3.put_object(Bucket=daily_data_bucket_name, Key=daily_data_prefix + filename, Body=response.text)
            print(f"Data fetched and uploaded to {daily_data_bucket_name}/{daily_data_prefix}{filename}")
        else:
            print(f"Error fetching data from {api_endpoint}. Status code: {response.status_code}")

    return {
        'statusCode': 200,
        'body': 'Data collection completed successfully.'
    }
