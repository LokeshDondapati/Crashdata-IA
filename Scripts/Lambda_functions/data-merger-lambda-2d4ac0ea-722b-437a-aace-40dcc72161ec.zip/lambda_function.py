import boto3

# Initialize S3 resource
s3 = boto3.resource('s3')

def lambda_handler(event, context):
    # Move files from 'new_data' to 'historical_Data/' in 'historical-data-bucket-ia-final'
    move_data('historical-data-bucket-ia-final', 'historical-data-bucket-ia-final', 'new_data/', 'historical_Data/')
    ensure_folder_exists('historical-data-bucket-ia-final', 'historical_Data/')

    # Delete files in 'daily_data/' from 'daily-data-bucket-ia-final'
    empty_folder('daily-data-bucket-ia-final', 'daily_data/')
    ensure_folder_exists('daily-data-bucket-ia-final', 'daily_data/')

    # Move files from 'cleaned_data/' in 'cleanedatabucket' to 'new_data/' in 'historical-data-bucket-ia-final'
    move_data('cleanedatabucket', 'historical-data-bucket-ia-final', 'cleaned_data/', 'new_data/')
    ensure_folder_exists('historical-data-bucket-ia-final', 'new_data/')

    return {
        'statusCode': 200,
        'body': 'Data operations and folder maintenance completed successfully.'
    }

def move_data(source_bucket_name, target_bucket_name, source_prefix, target_prefix):
    source_bucket = s3.Bucket(source_bucket_name)
    target_bucket = s3.Bucket(target_bucket_name)
    for obj in source_bucket.objects.filter(Prefix=source_prefix):
        new_key = f"{target_prefix}{obj.key[len(source_prefix):]}"  # Create new key with target prefix
        if not obj.key.endswith('/'):  # Skip placeholder or empty directory keys
            s3.Object(target_bucket.name, new_key).copy_from(CopySource={'Bucket': source_bucket.name, 'Key': obj.key})
            print(f"Copied {obj.key} to {new_key}")
            obj.delete()
            print(f"Deleted {obj.key}")

def empty_folder(bucket_name, prefix):
    bucket = s3.Bucket(bucket_name)
    for obj in bucket.objects.filter(Prefix=prefix):
        if not obj.key.endswith('/'):  # Skip placeholder or empty directory keys
            obj.delete()
            print(f"Deleted {obj.key}")

def ensure_folder_exists(bucket_name, folder_path):
    folder_key = f"{folder_path.rstrip('/')}/"  # Ensure the folder path ends with '/'
    obj = s3.Object(bucket_name, folder_key)
    obj.put(Body='')  # Put an empty string to make the object
    print(f"Placeholder for {folder_path} added in {bucket_name}")

