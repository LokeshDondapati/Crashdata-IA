import boto3
import pandas as pd
from io import StringIO

# Initialize boto3 client
s3_client = boto3.client('s3')

def lambda_handler(event, context):
    # Updated source bucket and prefix
    source_bucket = 'daily-data-bucket-ia-final'
    source_prefix = 'daily_data/'  # Updated to include the folder

    # Updated target bucket and prefix
    target_bucket = 'cleanedatabucket'
    target_prefix = 'cleaned_data/'  # Updated to include the folder

    file_names = ['crashes.csv', 'vehicles.csv', 'person.csv']
    
    for file_name in file_names:
        try:
            # Get the object from the bucket with the updated path
            file_obj = s3_client.get_object(Bucket=source_bucket, Key=source_prefix + file_name)
            file_data = file_obj['Body'].read().decode('utf-8')
            df = pd.read_csv(StringIO(file_data))
            print(f"Original data columns for {file_name}: {df.columns.tolist()}")

            df = clean_data(df, file_name)
            print(f"Columns after cleaning for {file_name}: {df.columns.tolist()}")
            print(f"Cleaned data size for {file_name}: {df.shape}")

            if not df.empty:
                csv_buffer = StringIO()
                df.to_csv(csv_buffer, index=False)
                # Writing the cleaned data to the updated path
                s3_client.put_object(Bucket=target_bucket, Key=target_prefix + f'cleaned_{file_name}', Body=csv_buffer.getvalue())
            else:
                print(f"No data to write after cleaning for file: {file_name}")
        except Exception as e:
            print(f"Error processing file {file_name}: {str(e)}")

def clean_data(df, file_name):
    # Cleaning logic remains unchanged
    if 'borough' in df.columns:
        df['borough'] = df['borough'].fillna('Unknown')
    if 'zip_code' in df.columns:
        df['zip_code'] = df['zip_code'].fillna('Unknown')
    if 'latitude' in df.columns and 'longitude' in df.columns:
        df.dropna(subset=['latitude', 'longitude'], inplace=True)
    if 'crash_date' in df.columns:
        df['crash_date'] = pd.to_datetime(df['crash_date'], errors='coerce')
    if 'unique_id' in df.columns:
        df.drop_duplicates(subset=['unique_id'], inplace=True)
    for col in df.columns:
        if df[col].isnull().mean() > 0.5:
            df.drop(columns=[col], inplace=True)
    if file_name == 'vehicles.csv':
        target_column = 'driver_sex'
        if target_column in df.columns:
            df.drop(columns=[target_column], inplace=True)
    return df
